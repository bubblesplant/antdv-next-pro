# pro-table-basic-query-table

将全部文件放在同一目录，通过 Example.vue 引入示例。

依赖：Vue 3.5+、antdv-next 1.5+、@bubblesjs/antv-next-pro。

在应用入口全局引入：

import 'antdv-next/dist/reset.css'
import '@bubblesjs/antv-next-pro/style.css'
