<script setup lang="ts">
import ProTableScenario from './ProTableScenario.vue'
import type { ProTableDemoScenario } from './scenarios'

const scenario: ProTableDemoScenario = {
  "id": "basic-query-table",
  "title": "查询表格",
  "group": "basic",
  "description": "用远程 request 串联查询、分页、排序和筛选的标准 ProTable。",
  "validationPoints": [
    "首次进入自动请求数据",
    "查询后回到第一页",
    "分页、排序和筛选参数正确传入 request"
  ],
  "implementation": "native",
  "mode": "query-table",
  "order": 1
}
</script>

<template>
  <ProTableScenario :scenario="scenario" />
</template>
