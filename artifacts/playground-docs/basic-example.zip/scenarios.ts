export type ProTableDemoImplementation = 'native' | 'vue-map'

export type ProTableDemoGroupId =
  | 'basic'
  | 'search-bar-type'
  | 'search-and-filter'
  | 'custom-search-form'
  | 'table-features'
  | 'custom-toolbar'
  | 'card-table'
  | 'no-search-table'
  | 'value-types'
  | 'internationalization'
  | 'rtl'
  | 'theme'
  | 'error-boundary'
  | 'other-examples'
  | 'list-toolbar'

export type ProTableDemoValidationPoints =
  | readonly [string, string]
  | readonly [string, string, string]
  | readonly [string, string, string, string]

export interface ProTableDemoScenario {
  order: number
  id: string
  title: string
  group: ProTableDemoGroupId
  description: string
  validationPoints: ProTableDemoValidationPoints
  implementation: ProTableDemoImplementation
  mode: string
}

