# pro-table-basic-query-table

保留文件目录结构，通过 pro-table/BasicQueryTable.vue 引入示例。

依赖：Vue 3.5+、antdv-next 1.5+、@bubblesjs/antv-next-pro。

在应用入口全局引入：

import 'antdv-next/dist/reset.css'
import '@bubblesjs/antv-next-pro/style.css'
